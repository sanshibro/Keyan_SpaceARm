"""Read-only local body reachability diagnostic for a rejected causal window."""
import json,time
import numpy as np
from m2_geometry import Geometry,RangeMap
from m2_plant import build,STAGE
from m2_rolling import clean

def main():
    source=STAGE/'qa/planner/walk-coupled/summary.json';log=json.loads(source.read_text());current=np.asarray(log['windows'][-1]['state'])
    p=build();snap=RangeMap(p).reveal(0,current);g=Geometry(p,snapshot=snap);comp=g.local(0,0)[0];comp=np.ascontiguousarray(comp[comp[:,7]==0])
    records=[]
    for x in (2.55,2.65,2.75,2.83,2.90):
        states=np.array([[x,y,z,psi,0.,0.] for y in np.arange(-.44,.481,.04) for z in np.arange(1.86,2.121,.02) for psi in np.deg2rad(np.arange(-90,91,15))])
        coarse=np.array([g.query(comp,s)[0][0] for s in states]);order=np.argsort(coarse)[::-1][:240];best=[];start=time.monotonic()
        for j in order:
            r=g.convex_map.query(states[j],groups=(0,))[0];best.append((r['lower'],states[j].tolist(),r))
        best.sort(key=lambda z:z[0],reverse=True)
        row=dict(x=x,coarse_max=float(coarse.max()),best=best[:8],seconds=time.monotonic()-start,coarse_count=len(states),exact_count=len(order));records.append(row)
        print(x,row['best'][:2],row['seconds'],flush=True)
    (STAGE/'qa/planner/local-body-reach.json').write_text(json.dumps(clean(dict(current=current,map=snap.metadata(),rows=records)),indent=2))

if __name__=='__main__':main()
