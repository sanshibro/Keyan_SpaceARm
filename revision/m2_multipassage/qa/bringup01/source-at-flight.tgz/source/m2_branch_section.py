"""Independent static search for rigid SUPER passage at the G2 service branch."""
import argparse,json,time
from pathlib import Path
import mujoco,numpy as np
from scipy.optimize import differential_evolution
from scipy.optimize import minimize
from m2_geometry import NativeSelf
from m2_plant import build,place
from m2_self_registry import partition
from gate_distance_audit import DistanceAudit
from m2_inspection_ik import certify_tilt


class Section:
    def __init__(self,p,x):
        self.m=p.m;self.d=mujoco.MjData(p.m);self.x=float(x)
        self.audit=DistanceAudit(p.m,obstacle_prefix='COL_',tolerance_m=.0001,strict=False)
        self.native=NativeSelf(p.m)
        all_pairs=self.audit.external['body']; unique=np.unique(all_pairs[:,1]);d=self.d;m=self.m
        mujoco.mj_kinematics(m,d)
        # Broad-phase world-X exclusion for all yaw: bounding sphere of the
        # complete rigid group and geometries on the fixed world side.
        self.ids=np.unique(all_pairs[:,0]);self.obs=unique
        self.ids=np.asarray(self.ids);self.base=m.body('uav').id
        pos=d.geom_xpos[self.ids]-d.xpos[self.base]
        arm=np.linalg.norm(pos,axis=1)+np.linalg.norm(m.geom_aabb[self.ids,:3],axis=1)+np.linalg.norm(m.geom_aabb[self.ids,3:],axis=1)
        self.radius=float(arm.max())
        centers=d.geom_xpos+(d.geom_xmat.reshape(-1,3,3)@m.geom_aabb[:,:3,None])[:,:,0]
        half=(abs(d.geom_xmat.reshape(-1,3,3))@m.geom_aabb[:,3:,None])[:,:,0]
        selected=unique[np.abs(centers[unique,0]-x)<=self.radius+half[unique,0]+.25]
        self.pairs=np.ascontiguousarray(all_pairs[np.isin(all_pairs[:,1],selected)],np.int32)
        self.geo_cache={}
    def state(self,coords,signed=True):
        y,z,yaw=coords;xyz=[self.x,y,z]
        d=self.d;d.qpos[:3]=xyz;r=np.deg2rad(yaw)/2;d.qpos[3:7]=[np.cos(r),0.,0.,np.sin(r)]
        mujoco.mj_kinematics(self.m,d)
        r=self.native.query(d,self.pairs)
        if r['upper']<=0 and signed:
            # Optimize a signed surrogate inside collision; the exact final
            # witness is certified independently after optimization.
            a,b=r['which'];m=self.m;delta=d.geom_xpos[a]-d.geom_xpos[b]
            lo,hi=self._bounds();sep=np.maximum(lo[a]-hi[b],lo[b]-hi[a])
            return max(-.15,min(-.00001,float(sep.max())))
        return float(r['lower'])
    def _bounds(self):
        R=self.d.geom_xmat.reshape(-1,3,3);m=self.m
        c=self.d.geom_xpos+(R@m.geom_aabb[:,:3,None])[:,:,0]
        h=(abs(R)@m.geom_aabb[:,3:,None])[:,:,0];return c-h,c+h
    def certify(self,coords):
        self.state(coords)
        a=self.audit;a.d.qpos[:]=self.d.qpos;mujoco.mj_kinematics(self.m,a.d)
        lo,hi=a.bounds();r=a._scan('body',a.external['body'],lo,hi)
        tilt=certify_tilt(a.d,a,self.native,a.external['body'])
        return dict(y=float(coords[0]),z=float(coords[1]),yaw_deg=float(coords[2]),body_lower_m=r['lower'],
            body_upper_m=r['upper'],nearest=[r['name_a'],r['name_b']],tilt=tilt)


def explore(plant,output,xs):
    output=Path(output);output.mkdir(parents=True,exist_ok=True);sections=[]
    for x in xs:
        s=Section(plant,x);rows=[];found=[];start=time.monotonic()
        for side,(yl,yh) in enumerate([(-.78,0.),(0.,.78)]):
            for iy,yaw0 in enumerate(np.arange(-180.,180.,60.)):
                best=differential_evolution(lambda q:-s.state(q),
                    [(yl,yh),(1.65,2.12),(yaw0,yaw0+60.)],popsize=5,maxiter=26,
                    polish=True,tol=.0003,seed=2111+side*100+iy,updating='deferred')
                v=s.certify(best.x);v['search']=[side,yaw0,yaw0+60.];rows.append(v)
                if v['body_lower_m']>=.085:found.append(v)
        result=dict(x=float(x),cases=rows,qualifying_nominal=len(found),seconds=time.monotonic()-start)
        sections.append(result)
        (output/'body-cross-sections.json').write_text(json.dumps(dict(scene=plant.scene_digest,sections=sections),indent=2)+'\n')
        best=max(rows,key=lambda r:r['body_lower_m']);print(x,best,flush=True)
    return sections


def join(plant,output):
    """Search both roll-equivalent yaw branches at successive longitudinal slices."""
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    xs=np.linspace(2.68,3.04,19);yaws=np.arange(-140.,-34.9,5.)
    cache=output/'joined-body.json'
    saved=json.loads(cache.read_text()) if cache.is_file() else None
    if saved and saved['scene']==plant.scene_digest:layers=saved['layers']
    else:
        layers=[];previous={}
        for x in xs:
            s=Section(plant,x);nodes=[];current={}
            for yaw in yaws:
                seeds=[previous.get(yaw,[.37,1.94]),[.4,1.91]]
                states=[]
                for initial in seeds:
                    f=lambda p:-s.state([p[0],p[1],yaw])
                    best=minimize(f,initial,method='Nelder-Mead',
                        bounds=[(.14,.63),(1.77,2.05)],options=dict(maxiter=28,xatol=.0009,fatol=.00025))
                    states.append((float(-best.fun),best.x))
                gap,yz=max(states,key=lambda v:v[0]);current[yaw]=yz
                nodes.append(dict(q=[float(x),*list(map(float,yz)),float(yaw)],gap_m=gap))
            previous=current;layers.append(nodes)
    # Penalize turning and translation but maximize the worst registered body gap.
    # Feasible edges are assessed again on the raw native model below.
    cost=np.array([r['gap_m'] for r in layers[0]])
    predecessors=[]
    for i in range(1,len(xs)):
        prior=np.array([r['q'] for r in layers[i-1]]);nxt=[];pred=[]
        for node in layers[i]:
            dif=prior-node['q']
            ok=(abs(dif[:,3])<=10.01)&(np.linalg.norm(dif[:,1:3],axis=1)<=.11)
            scores=np.where(ok,np.minimum(cost,node['gap_m'])-abs(dif[:,3])*.000003,-np.inf)
            j=int(np.argmax(scores));pred.append(j);nxt.append(scores[j])
        cost=np.array(nxt);predecessors.append(pred)
    j=int(np.argmax(cost));picked=[]
    if not np.isfinite(cost[j]):raise ValueError('No connected branch within the sampled states')
    for i in range(len(xs)-1,-1,-1):
        picked.append(layers[i][j]['q'])
        if i:j=predecessors[i-1][j]
    picked.reverse()
    output.joinpath('joined-body.json').write_text(json.dumps(dict(scene=plant.scene_digest,
        layers=layers,picked=picked),indent=2)+'\n')
    print('joined node lower bound before edge proof',float(cost.max()),'first/last',picked[0],picked[-1],flush=True)
    return picked


def whole(plant,route,output):
    # Offline witnesses on the original convex CAD and registered pairs.
    s=Section(plant,float(route[0][0]));audit=s.audit;m=plant.m;d=audit.d
    hazard,fit=partition(m,audit.self_pairs);arm=audit.external['arm_tool']
    shapes=[]
    for t in (50.,65.,80.,95.,110.):
        for f in np.arange(0.,360.,15.):
            place(m,d,[0,0,0],t,f);h=s.native.query(d,hazard);a=s.native.query(d,fit)
            if h['lower']>=.015 and a['lower']>=0:shapes.append([t,f])
    shapes=np.array(shapes);layers=[]
    for x,y,z,yaw in route:
        vals=[]
        for t,f in shapes:
            place(m,d,[x,y,z],t,f,yaw);v=s.native.query(d,arm);vals.append(v['lower'])
        layers.append(vals)
    dphi=(shapes[:,1,None]-shapes[None,:,1]+180.)%360.-180.
    links=(abs(shapes[:,0,None]-shapes[None,:,0])<=15.)&(abs(dphi)<=30.)
    cost=np.asarray(layers[0]);back=[]
    for vals in layers[1:]:
        scores=np.minimum(cost[:,None],np.array(vals)[None,:])-.000001*abs(dphi)
        scores=np.where(links,scores,-np.inf);back.append(np.argmax(scores,axis=0));cost=np.max(scores,axis=0)
    ix=int(np.argmax(cost));idx=[]
    for j in range(len(route)-1,-1,-1):
        idx.insert(0,ix)
        if j:ix=int(back[j-1][ix])
    shape=shapes[idx].copy();shape[:,1]=np.rad2deg(np.unwrap(np.deg2rad(shape[:,1])))
    q=np.column_stack((route,shape));samples=[];distances=dict()
    for l,r in zip(q,q[1:]):
        n=int(np.ceil(max(np.linalg.norm(r[:3]-l[:3])/.002,
                            max(abs(r[3:]-l[3:]))/.35)))
        for u in np.arange(n)/n:samples.append(l+u*(r-l))
    samples.append(q[-1])
    minimum={k:[np.inf,None,None] for k in ('body','arm','hazard','fit')}
    traces=[]
    for q0 in samples:
        x,y,z,yaw,theta,phi=q0;place(m,d,[x,y,z],theta,phi,yaw);row={}
        for key,ps in [('body',audit.external['body']),('arm',arm),('hazard',hazard),('fit',fit)]:
            v=s.native.query(d,ps);row[key]=v['lower']
            if v['lower']<minimum[key][0]:
                minimum[key]=[v['lower'],q0.tolist(),[m.geom(int(i)).name for i in v['which']]]
        traces.append(row)
    lifted={}
    for key,pairs in [('arm',arm),('body',audit.external['body'])]:
        worst=[np.inf,None,None];robust=[]
        for i,q0 in enumerate(samples):
            x,y,z,yaw,theta,phi=q0;place(m,d,[x,y,z],theta,phi,yaw)
            # A rotation cannot move a rigid point farther than its radius
            # times the chord; skip the dense angle grid when that suffices.
            a,b=pairs.T
            centers=d.geom_xpos+(d.geom_xmat.reshape(-1,3,3)@m.geom_aabb[:,:3,None])[:,:,0]
            radii=np.linalg.norm(centers-np.array([x,y,z]),axis=1)+np.linalg.norm(m.geom_aabb[:,3:],axis=1)
            estimate=traces[i][key]-2*np.sin(np.deg2rad(1.))*radii[a].max()
            if estimate>=.090:proof={'lower_m':float(estimate),'cells':0}
            else:proof=certify_tilt(d,audit,s.native,pairs)
            robust.append(proof['lower_m'])
            if proof['lower_m']<worst[0]:worst=[proof['lower_m'],q0.tolist(),proof]
        lifted[key]=dict(minimum=worst,lower_m=robust)
    out=dict(scene=plant.scene_digest,nodes=q.tolist(),sample_states=np.array(samples).tolist(),samples=traces,
             all_two_degree_tilts=lifted,
             minimum=minimum,sample_count=len(samples),motor_flight=False)
    Path(output,'joined-whole.json').write_text(json.dumps(out,indent=2)+'\n')
    print('whole pose witnesses',json.dumps(minimum),len(samples),flush=True)
    print('all two-degree tilts',json.dumps({k:v['minimum'] for k,v in lifted.items()}),flush=True)
    return out


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('x',type=float,nargs='*');p.add_argument('--join',action='store_true');a=p.parse_args()
    if a.join:
        plant=build();whole(plant,join(plant,a.output),a.output)
    else:explore(build(),a.output,a.x)
