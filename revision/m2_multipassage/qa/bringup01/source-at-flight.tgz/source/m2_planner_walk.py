"""Causal command-space window exercise: no physics integration, aircraft or flight.

Each next observation is taken only on the preceding accepted local spline.
This checks planner reachability/timing; it is not a tracking experiment.
"""
import json,time
from pathlib import Path
import numpy as np
from m2_plant import build,task_pose,STAGE
from m2_scene import HOVER
from m2_geometry import RangeMap
from m2_planner import Kernel
from m2_rolling import clean

def run(method='coupled',count=7):
    p=build();sensor=RangeMap(p);goal=task_pose(p)
    try:
        from m2_inspection_ik import goal_family
        goal['candidates']=goal_family(p,goal)
    except ImportError:pass
    before=time.monotonic();kernel=Kernel(p,method,goal);prep=time.monotonic()-before
    q=np.r_[HOVER,0.,0.,np.pi];v=np.zeros(6);a=np.zeros(6);release=21.;records=[]
    folder=STAGE/'qa/planner'/('walk-'+method);folder.mkdir(parents=True,exist_ok=True)
    for k in range(count):
        snap=sensor.reveal(release,q);start=time.monotonic()
        try:
            result=kernel.solve(snap,q,v,a,k);curve=result['curve']
            record=dict(window=k,state=q.tolist(),map=snap.metadata(),accepted=True,timing=result['timing'],duration_s=curve.duration,
                        end=curve.evaluate([curve.duration],0)[0].tolist(),proof=clean(result['proof']))
            ts=np.linspace(0,curve.duration,2001);states=curve.evaluate(ts,0)
            advance=np.flatnonzero(states[:,0]>=q[0]+.78)
            if not len(advance):cut=curve.duration
            else:cut=float(ts[advance[0]])
            np.savez_compressed(folder/('window-%02d.npz'%k),t=ts,q=states,dq=curve.evaluate(ts,1),ddq=curve.evaluate(ts,2),
                                control_states=curve.control_states,span_durations=curve.span_durations,seed=result['route'])
            if result['final']:records.append(record);break
            nextq=curve.evaluate([cut],0)[0];v=curve.evaluate([cut],1)[0];a=curve.evaluate([cut],2)[0]
            if cut>=curve.duration-1e-6:v[:]=0;a[:]=0
            release+=cut
            if nextq[0]<=q[0]+.01:record['zero_progress']=True;records.append(record);break
            q=nextq
        except Exception as exc:
            record=dict(window=k,state=q.tolist(),map=snap.metadata(),accepted=False,error=str(exc),wall_s=time.monotonic()-start,
                        timing=getattr(exc,'timing',None),proof=clean(getattr(exc,'proof',None)),layers=getattr(exc,'layers',None))
            records.append(record);print('REJECT',k,record['error'],record['timing'],flush=True);break
        records.append(record);print('WINDOW',k,record['state'][:3],'->',record['end'][:3],record['duration_s'],record['timing'],flush=True)
    result=dict(kind='static command-space exercise only',flight_executed=False,scene_hash=p.scene_digest,method=method,preparation_s=prep,windows=records)
    (folder/'summary.json').write_text(json.dumps(clean(result),indent=2));return result

if __name__=='__main__':run()
